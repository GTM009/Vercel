import { motion } from "framer-motion";
import { Calculator, Play, CreditCard, ShoppingBag, Music, ExternalLink, Send } from "lucide-react";
import { useState } from "react";
import heroBg from "@/assets/hero-bg.png";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";

export function Navbar() {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 border-b border-white/10 bg-background/80 backdrop-blur-md">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-background font-bold">
            B
          </div>
          <span className="text-xl font-bold tracking-tight">BoltRentalServices</span>
        </div>
        <div className="flex items-center gap-4">
          <Button variant="outline" asChild className="border-white/10 hover:bg-white/5">
            <a href="https://t.me/OurWorkProofs" target="_blank" rel="noopener noreferrer">
              <ExternalLink className="mr-2 h-4 w-4" />
              Work Proofs & Contact
            </a>
          </Button>
        </div>
      </div>
    </nav>
  );
}

export function Hero() {
  return (
    <section className="relative min-h-[90vh] flex items-center pt-20 overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src={heroBg} 
          alt="Background" 
          className="h-full w-full object-cover opacity-40"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-transparent to-transparent" />
      </div>

      <div className="container relative z-10 mx-auto grid gap-12 px-4 md:grid-cols-2 items-center">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="space-y-6"
        >
          <div className="inline-flex items-center rounded-full border border-primary/20 bg-primary/10 px-3 py-1 text-sm font-medium text-primary backdrop-blur-sm">
            <span className="flex h-2 w-2 rounded-full bg-primary mr-2 animate-pulse"></span>
            Premium Rental Access
          </div>
          <h1 className="text-5xl font-extrabold leading-tight tracking-tight sm:text-6xl md:text-7xl">
            Movie & Series <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">Rentals.</span>
          </h1>
          <p className="max-w-xl text-lg text-muted-foreground md:text-xl">
            Premium overseas movie and series rentals for Amazon, Prime Video, Google Play, and iTunes. Verified quality, fast delivery.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Button size="lg" asChild className="bg-primary text-primary-foreground hover:bg-primary/90 text-lg h-12 px-8">
              <a href="https://t.me/OurWorkProofs" target="_blank" rel="noopener noreferrer">
                View Proofs & Contact
              </a>
            </Button>
            <div className="hidden sm:block">
              {/* Removed separate contact button as per user request */}
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <PricingCalculator />
        </motion.div>
      </div>
    </section>
  );
}

function PricingCalculator() {
  const [priceInput, setPriceInput] = useState<string>("10");
  
  const priceValue = parseFloat(priceInput) || 0;
  const discount70 = (priceValue * 0.7).toFixed(2);
  const discount80 = (priceValue * 0.8).toFixed(2);
  const savings = (priceValue - (priceValue * 0.7)).toFixed(2);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    // Allow empty string or numbers only
    if (val === "" || /^\d*\.?\d*$/.test(val)) {
      setPriceInput(val);
    }
  };

  return (
    <Card className="border-white/10 bg-white/5 backdrop-blur-xl shadow-2xl overflow-hidden relative group">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-secondary/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      <CardContent className="p-8 space-y-8 relative z-10">
        <div className="space-y-2">
          <h3 className="text-2xl font-bold flex items-center gap-2">
            <Calculator className="h-6 w-6 text-primary" />
            Savings Calculator
          </h3>
          <p className="text-muted-foreground">See how much you save with BoltRentalServices.</p>
        </div>

        <div className="space-y-6">
          <div className="space-y-3">
            <label className="text-sm font-medium text-muted-foreground">Original Rental Price ($)</label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground text-lg">$</span>
              <Input 
                type="text" 
                value={priceInput} 
                onChange={handleInputChange}
                className="pl-8 h-14 text-2xl font-bold bg-background/50 border-white/10 focus-visible:ring-primary"
                placeholder="0"
              />
            </div>
            <Slider 
              value={[priceValue]} 
              max={100} 
              step={1} 
              onValueChange={(vals) => setPriceInput(vals[0].toString())}
              className="py-4"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="rounded-xl bg-primary/10 p-4 border border-primary/20 text-center space-y-1">
              <div className="text-sm font-medium text-primary/80">70% Rate</div>
              <div className="text-3xl font-bold text-primary">${discount70}</div>
              <div className="text-xs text-muted-foreground">You pay</div>
            </div>
            <div className="rounded-xl bg-secondary/10 p-4 border border-secondary/20 text-center space-y-1">
              <div className="text-sm font-medium text-secondary/80">80% Rate</div>
              <div className="text-3xl font-bold text-secondary">${discount80}</div>
              <div className="text-xs text-muted-foreground">You pay</div>
            </div>
          </div>
          
          <div className="rounded-lg bg-green-500/10 p-3 text-center border border-green-500/20">
            <span className="text-green-400 font-medium">You save up to ${savings} per rental!</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

const services = [
  {
    title: "Amazon & Prime Video",
    icon: Play,
    color: "text-blue-400",
    description: "Premium movie & series rentals across global regions.",
    regions: ["Italy", "Spain", "Sweden", "Belgium", "Poland", "Australia", "Mexico", "Portugal", "Finland", "New Zealand", "Brazil", "Canada", "US", "UK", "Germany", "Japan", "Denmark"]
  },
  {
    title: "Google Play",
    icon: ShoppingBag,
    color: "text-green-500",
    description: "Movies & Series. Full payment (No discount). Conditional discounts available for specific titles.",
    regions: ["India", "US"]
  },
  {
    title: "iTunes & Apple TV",
    icon: Music,
    color: "text-pink-500",
    description: "Premium 4K rentals. Full payment (No discount). Conditional discounts available for specific titles.",
    regions: ["DE", "GB", "PL"]
  }
];

export function Services() {
  return (
    <section className="py-24 bg-card/50">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-4">
          <h2 className="text-3xl md:text-5xl font-bold">Movies & Series Rentals</h2>
          <p className="text-muted-foreground text-lg">
            High-quality rentals across your favorite platforms.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="h-full border-white/5 bg-white/[0.02] hover:bg-white/[0.05] transition-all duration-300">
                <CardContent className="p-8 space-y-6">
                  <div className={`h-14 w-14 rounded-2xl bg-white/5 flex items-center justify-center ${service.color} shadow-lg shadow-white/5`}>
                    <service.icon className="h-8 w-8" />
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-2xl font-bold">{service.title}</h3>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      {service.description}
                    </p>
                  </div>
                  
                  <div className="pt-4 border-t border-white/5">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-3">Available Regions</h4>
                    <div className="flex flex-wrap gap-2">
                      {service.regions.map(region => (
                        <span key={region} className="px-2 py-1 rounded-md bg-white/5 border border-white/10 text-[10px] font-medium text-white/70">
                          {region}
                        </span>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="py-12 border-t border-white/10 bg-background">
      <div className="container mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-background font-bold">
            B
          </div>
          <span className="text-xl font-bold tracking-tight">BoltRentalServices</span>
        </div>
        <p className="text-sm text-muted-foreground">
          © {new Date().getFullYear()} BoltRentalServices. All rights reserved.
        </p>
        <div className="flex gap-6">
          <a href="https://t.me/OurWorkProofs" target="_blank" rel="noopener noreferrer" className="text-sm text-muted-foreground hover:text-primary transition-colors">Proofs</a>
          <a href="https://t.me/OurWorkProofs" target="_blank" rel="noopener noreferrer" className="text-sm text-muted-foreground hover:text-primary transition-colors">Telegram</a>
          <a href="https://t.me/OurWorkProofs" target="_blank" rel="noopener noreferrer" className="text-sm text-muted-foreground hover:text-primary transition-colors">Contact</a>
        </div>
      </div>
    </footer>
  );
}
