import { Navbar, Hero, Services, Footer } from "@/components/landing/LandingComponents";

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground font-sans selection:bg-primary/30">
      <Navbar />
      <Hero />
      <Services />
      <Footer />
    </div>
  );
}
